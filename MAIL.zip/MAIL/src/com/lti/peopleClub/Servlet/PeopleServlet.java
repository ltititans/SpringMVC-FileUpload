package com.lti.peopleClub.Servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.lti.peopleClub.BeanClass.PeopleClub;
import com.lti.peopleClub.DAO.PeopleDAO;




@WebServlet("/")
public class PeopleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;       
	private PeopleDAO peopleDAO;	
	public void init() {
		peopleDAO = new PeopleDAO();
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/new":
				showNewForm(request, response);
				break;
			case "/insert":
				insertPeople(request, response);
				break;
			case "/delete":
				deletePeople(request, response);
				break;
			case "/edit":
				showEditPeople(request, response);
				break;
			case "/update":
				updatePeople(request, response);
				break;
			default:
				listPeople(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}
	
	private void listPeople(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<PeopleClub> listPeople = peopleDAO.selectAllPeople();
		request.setAttribute("listPeople", listPeople);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-list.jsp");
		dispatcher.forward(request, response);
	}
	
	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-form.jsp");
		dispatcher.forward(request, response);
	}
	
	private void showEditPeople(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		PeopleClub existingPeople = peopleDAO.selectPeople(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("user-form.jsp");
		request.setAttribute("user", existingPeople);
		dispatcher.forward(request, response);

	}
	
	private void insertPeople(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		String fname = request.getParameter("fname");
		String lname = request.getParameter("lname");
		String dob = request.getParameter("dob");
		String city = request.getParameter("city");
		
		PeopleClub newPeople = new PeopleClub(id,fname, lname, dob, city);
		peopleDAO.insertPeople(newPeople);
		response.sendRedirect("list");
	}
	
	private void updatePeople(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		String fname = request.getParameter("fname");
		String lname = request.getParameter("lname");
		String dob = request.getParameter("dob");
		String city = request.getParameter("city");

		PeopleClub book = new PeopleClub(id, fname, lname, dob, city);
		peopleDAO.updatePeople(book);
		response.sendRedirect("list");
	}

	private void deletePeople(HttpServletRequest request, HttpServletResponse response) 
			throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		peopleDAO.deletePeople(id);
		response.sendRedirect("list");

	}
	
}
