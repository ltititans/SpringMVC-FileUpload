package com.lti.peopleClub.BeanClass;

public class PeopleClub {
	
	protected int id;
	protected String fname;
	protected String lname;
	protected String dob;
	protected String city;
	
	public PeopleClub()
	{
		
	}
	
	public PeopleClub(String fname, String lname, String dob, String city) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.dob = dob;
		this.city = city;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public PeopleClub(int id, String fname, String lname, String dob, String city) {
		super();
		this.id = id;
		this.fname = fname;
		this.lname = lname;
		this.dob = dob;
		this.city = city;
	}
	
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	@Override
	public String toString() {
		return "PeopleClub [id=" + id + ", fname=" + fname + ", lname=" + lname + ", dob=" + dob + ", city=" + city
				+ "]";
	}
}
