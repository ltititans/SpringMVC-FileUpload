package com.lti.peopleClub.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.lti.peopleClub.BeanClass.PeopleClub;

public class PeopleDAO {


	private String jdbcURL = "jdbc:oracle:thin:@localhost:1521:xe";
	private String jdbcUsername = "system";
	private String jdbcPassword = "tiger";

	private static final String INSERT_PEOPLE_SQL = "INSERT INTO peopleclub VALUES "
			+ " (?,?, ?, ?,?)";

	private static final String SELECT_PEOPLE_BY_ID = "select id,fname,lname,"
			+ "dob,city from peopleclub where id =?";
	private static final String SELECT_ALL_PEOPLE = "select * from peopleclub";
	private static final String DELETE_PEOPLE_SQL = "delete from peopleclub where id = ?";
	private static final String UPDATE_PEOPLE_SQL = "update peopleclub set fname = ?,"
			+ "lname= ?, dob =?, city=? where id = ?";

	public PeopleDAO() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, 
					jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	public void insertPeople(PeopleClub user) throws SQLException {
		System.out.println(INSERT_PEOPLE_SQL);
		// try-with-resource statement will auto close the connection.
		try {Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement
													(INSERT_PEOPLE_SQL);
				preparedStatement.setInt(1, user.getId());
			preparedStatement.setString(2, user.getFname());
			preparedStatement.setString(3, user.getLname());
			preparedStatement.setString(4, user.getDob());
			preparedStatement.setString(5, user.getCity());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public PeopleClub selectPeople(int id) {
		PeopleClub people = null;
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement
													(SELECT_PEOPLE_BY_ID);
			preparedStatement.setInt(1, id);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String fname = rs.getString("fname");
				String lname = rs.getString("lname");
				String dob = rs.getString("dob");
				String city = rs.getString("city");
				people = new PeopleClub(id, fname, lname, dob,city);
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return people;
	}

	public List<PeopleClub> selectAllPeople() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<PeopleClub> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		try {Connection connection = getConnection();

				// Step 2:Create a statement using connection object
			PreparedStatement preparedStatement = connection.prepareStatement
					(SELECT_ALL_PEOPLE);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int id = rs.getInt("id");
				String fname = rs.getString("fname");
				String lname = rs.getString("lname");
				String dob = rs.getString("dob");
				String city = rs.getString("city");
				users.add(new PeopleClub(id, fname, lname, dob, city));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	public boolean deletePeople(int id) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(DELETE_PEOPLE_SQL);) {
			statement.setInt(1, id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updatePeople(PeopleClub people) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(UPDATE_PEOPLE_SQL);) {
			statement.setString(1, people.getFname());
			statement.setString(2, people.getLname());
			statement.setString(3, people.getDob());
			statement.setString(4, people.getCity());
			statement.setInt(5, people.getId());

			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	private void printSQLException(SQLException ex) {
		
				ex.printStackTrace();
				
				}
			
		}
	


