package com.lti.Author.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
@Entity
@Table(name="Author123")
public class Author {
	
	
		
		@Id
		@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="person-seq")
		@SequenceGenerator(name="person-seq",sequenceName="per_seq",allocationSize=1)
		private long id;
		
		@Column
		private String Name;
		
		@Column
		private String bookName; 
		public long getId() {
			return id;
		}
		public void setId(long id) {
			this.id = id;
		}
		public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
		public String getBookName() {
			return bookName;
		}
		public void setBookName(String bookName) {
			this.bookName = bookName;
		}
		@Override
		public String toString() {
			return "User [id=" + id + ", Name=" + Name + ", bookName=" + bookName + "]";
		}
		
}

