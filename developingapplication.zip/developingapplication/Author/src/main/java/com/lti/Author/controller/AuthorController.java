package com.lti.Author.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lti.Author.entity.Author;
import com.lti.Author.service.AuthorService;


@Controller
public class AuthorController {
	// Constructor based Dependency Injection
	private AuthorService authorService;

	
	public AuthorController() {
		
	}


	@Autowired
	public AuthorController(AuthorService authorService) {
		
		this.authorService = authorService;
	}

	@RequestMapping(value = { "/", "/home" }, method = RequestMethod.GET)
	public ModelAndView hello(HttpServletResponse response) throws IOException {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("home");
		return mv;
	}

	// Get All Users
	@RequestMapping(value = "/allAuthors", method = RequestMethod.POST)
	public ModelAndView displayAllAuthor() {
		System.out.println("User Page Requested : All Users");
		ModelAndView mv = new ModelAndView();
		List<Author> authorList = authorService.getAllAuthors();
		mv.addObject("authorList", authorList);
		mv.setViewName("allAuthors");
		return mv;
	}

	@RequestMapping(value = "/addAuthor", method = RequestMethod.GET)
	public ModelAndView displayNewAuthorForm() {
		ModelAndView mv = new ModelAndView("addAuthor");
		mv.addObject("headerMessage", "Add Author Details");
		mv.addObject("author", new Author());
		return mv;
	}

	@RequestMapping(value = "/addAuthor", method = RequestMethod.POST)
	public ModelAndView saveNewAuthor(@ModelAttribute Author author, BindingResult result) {
		ModelAndView mv = new ModelAndView("redirect:/home");

		if (result.hasErrors()) {
			return new ModelAndView("error");
		}
		boolean isAdded = authorService.saveAuthor(author);
		if (isAdded) {
			mv.addObject("message", "New author successfully added");
		} else {
			return new ModelAndView("error");
		}

		return mv;
	}

	@RequestMapping(value = "/editAuthor/{id}", method = RequestMethod.GET)
	public ModelAndView displayEditAuthorForm(@PathVariable Long id) {
		ModelAndView mv = new ModelAndView("/editAuthor");
		Author author = authorService.getAuthorById(id);
		mv.addObject("headerMessage", "Edit Author Details");
		mv.addObject("author", author);
		return mv;
	}

	@RequestMapping(value = "/editAuthor/{id}", method = RequestMethod.POST)
	public ModelAndView saveEditedAuthor(@ModelAttribute Author author, BindingResult result) {
		ModelAndView mv = new ModelAndView("redirect:/home");

		if (result.hasErrors()) {
			System.out.println(result.toString());
			return new ModelAndView("error");
		}
		boolean isSaved = authorService.saveAuthor(author);
		if (!isSaved) {

			return new ModelAndView("error");
		}

		return mv;
	}

	@RequestMapping(value = "/deleteAuthor/{id}", method = RequestMethod.GET)
	public ModelAndView deleteAuthorById(@PathVariable Long id) {
		boolean isDeleted = authorService.deleteAuthorById(id);
		System.out.println("Author deletion respone: " + isDeleted);
		ModelAndView mv = new ModelAndView("redirect:/home");
		return mv;

	}

}

