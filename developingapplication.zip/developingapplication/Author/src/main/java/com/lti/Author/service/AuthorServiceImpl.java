package com.lti.Author.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.Author.entity.Author;
import com.lti.Author.repository.AuthorRepository;



@Service
@Transactional
public class AuthorServiceImpl implements AuthorService {
		// Implementing Constructor based DI
		private AuthorRepository repository;
		
		public AuthorServiceImpl() {
			
		}
		
		@Autowired
		public AuthorServiceImpl(AuthorRepository repository) {
			super();
			this.repository = repository;
		}
		
	public List<Author> getAllAuthors() {
		List<Author> list = new ArrayList<Author>();
		repository.findAll().forEach(e -> list.add(e));
		return list;
	}

	@Override
	public Author getAuthorById(Long id) {
		Author user = repository.findById(id).get();
		return user;
	}

	@Override
	public boolean saveAuthor(Author author) {
		try {
			repository.save(author);
			return true;
		}
		catch(Exception ex) {
			return false;
		}
	}

	@Override
	public boolean deleteAuthorById(Long id) {
		try {
			repository.deleteById(id);
			return true;
		}catch(Exception ex) {
			return false;
		}
		
	}

	

}

