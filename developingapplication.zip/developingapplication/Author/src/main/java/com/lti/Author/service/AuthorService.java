package com.lti.Author.service;

import java.util.List;

import com.lti.Author.entity.Author;



public interface AuthorService {

	public List<Author> getAllAuthors();
	public Author getAuthorById(Long id);
	public boolean saveAuthor(Author author);
	public boolean deleteAuthorById(Long id);

}
