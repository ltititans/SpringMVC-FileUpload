package com.lti.mvc;

import java.util.Properties;

import javax.sql.DataSource;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories("com.lti.mvc.repository")

@PropertySource(value={"classpath:application.properties"})
public class HibernateConfig {

	
	@Autowired
	private Environment env;
	
	
	//start of JPA config details
	
	@Bean(name="entityManagerFactory")
	public LocalContainerEntityManagerFactoryBean getEntityManagerFactoryBean()
	{
		LocalContainerEntityManagerFactoryBean abc = new LocalContainerEntityManagerFactoryBean();
		abc.setJpaVendorAdapter(getJpaVendorAdapter());
		abc.setDataSource(dataSource());
		abc.setPersistenceUnitName("myJpaPersistentUnit");
		abc.setPackagesToScan("com.lti.mvc");
		abc.setJpaProperties(hibernateProperties());
		return abc;
	}
	
	
	@Bean
	public JpaVendorAdapter getJpaVendorAdapter(){
		JpaVendorAdapter adapter=new HibernateJpaVendorAdapter();
		return adapter;
		
	}
	
	@Bean(name="transactionManager")
	public PlatformTransactionManager txManager(){
		JpaTransactionManager jpaTransactionManager=new JpaTransactionManager(getEntityManagerFactoryBean().getObject());
		return jpaTransactionManager;
	}
	
	@Bean
	public DataSource dataSource(){
		DriverManagerDataSource dataSource=new DriverManagerDataSource();
		dataSource.setDriverClassName(env.getRequiredProperty("jdbc.driver"));
		dataSource.setUrl(env.getRequiredProperty("jdbc.url"));
		dataSource.setUsername(env.getRequiredProperty("jdbc.username"));
		dataSource.setPassword(env.getRequiredProperty("jdbc.password"));
		return dataSource;
		
		
	}
	
	private Properties hibernateProperties(){
		Properties properties=new Properties();
		properties.put("hibernate.dialect", env.getRequiredProperty("hibernate.dialect"));
		properties.put("hibernate.show_sql", env.getRequiredProperty("hibernate.show_sql"));
		properties.put("hibernate.format_sql", env.getRequiredProperty("hibernate.format_sql"));
		properties.put("hibernate.hbm2ddl.auto", env.getRequiredProperty("hibernate.hbm2ddl.auto"));
		return properties;
	}
	
	
}
